<template>
  <header class="navbar">
    <div class="container h-100 d-flex justify-content-center align-items-center">
      <router-link to="/" class="navbar-logo">Модуль «Расчет Заказа Метролог»</router-link>
    </div>
  </header>
</template>

<style scoped>

.navbar
{
  height: 70px;
  background: #eee;
  border-bottom: 3px solid #07e;
}

.navbar-logo
{
  font-size: 32px;
  color: #07e;
  text-decoration: none;
}


</style>